﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class _Default : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void Loging(object sender, EventArgs e)
    {
        String User = email.Text;
        String Password = password.Text;
        codes code = new codes();
        if (code.Login(User, Password))
        {
            code.UserLogin = User;
            code.Numero_Pedidos_NoPagados();
            code.Numero_Pedidos_Pagados();
            if (code.ADMIN == true)
            {
                Response.Redirect("Vistas/index.aspx");
            }
            else
            {
                ClientScript.RegisterStartupScript(this.GetType(), "randomtext", "alertme2()", true);
            }
        }
        else
        {
            ClientScript.RegisterStartupScript(this.GetType(), "randomtext", "alertme()", true);
        }
    }
}