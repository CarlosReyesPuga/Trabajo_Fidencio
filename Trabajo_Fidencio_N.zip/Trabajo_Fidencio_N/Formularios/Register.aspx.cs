﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Formularios_Register : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void User_Register(object sender, EventArgs e)
    {
        String Name_User = Txt_Name.Text;
        String Last_User_Name = Txt_LastName.Text;
        String User_Name = Txt_Email.Text;
        String Password = Txt_Password.Text;
        codes code = new codes();

        bool bandera = code.Register_Usuario(Name_User, Last_User_Name, User_Name, Password);
        if (bandera)
        {
            ClientScript.RegisterStartupScript(this.GetType(), "randomtext", "alertme()", true);
        }
        else
        {
            ClientScript.RegisterStartupScript(this.GetType(), "randomtext", "alertme2()", true);
        }
    }
}