﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Formularios_forgot : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }

    protected void Register_User(object sender, EventArgs e)
    {

        String Password = Txt_Password.Text;
        String Rep_Password = Txt_Repeat_Password.Text;

        Txt_error_mensage.Text = "";

        if (Password == Rep_Password)
        {
            String User_Login = Txt_Email.Text;
            codes code = new codes();

            bool bandera = code.Forgot_Password(User_Login, Password);
            if (bandera)
            {
                ClientScript.RegisterStartupScript(this.GetType(), "randomtext", "alertme()", true);
            }
            else
            {
                ClientScript.RegisterStartupScript(this.GetType(), "randomtext", "alertme3()", true);
            }
        }
        else
        {
            ClientScript.RegisterStartupScript(this.GetType(), "randomtext", "alertme2()", true);
        }
    }
}