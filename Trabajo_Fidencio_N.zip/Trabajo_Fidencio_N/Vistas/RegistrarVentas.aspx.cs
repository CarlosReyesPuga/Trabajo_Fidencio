﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Vistas_RegistrarVentas : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!this.IsPostBack)
        {
            codes code = new codes();
            lbl_User.Text = code.UserLogin;
        }
    }

    protected void Registrar(object sender, EventArgs e)
    {
        DatosGuias.Guia = txt_Guia.Text;
        DatosGuias.Nombre_Comprador = txt_Nombre.Text;
        DatosGuias.Direccion = txt_Direccion.Text;
        DatosGuias.Monto_Pagar = txt_montoapagar.Text;
        DatosGuias.Descripcion = txt_Descripcion.Text;
        DatosGuias.Fecha_Venta = txt_fecha.Text;
        DatosGuias.Pagado = txt_pagado.Checked;
        codes code = new codes();
        if (code.Registrar_Datos())
        {
            Response.Redirect(code.Redireccion);
        }
    }

    protected void Regresar(object sender, EventArgs e)
    {
        codes code = new codes();
        Response.Redirect(code.Redireccion);
    }
}