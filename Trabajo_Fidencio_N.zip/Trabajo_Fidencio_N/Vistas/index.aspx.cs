﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Vistas_index : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!this.IsPostBack)
        {
            codes code = new codes();
            lbl_User.Text = code.UserLogin;
            code.Numero_Pedidos_NoPagados();
            code.Numero_Pedidos_Pagados();
            Label1.Text = code.PEDIDOS_NOPAGADOS.ToString();
            Label2.Text = code.PEDIDOS_PAGADOS.ToString();
        }
    }
}