﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;
using System.IO;
using iTextSharp.text;
using iTextSharp.text.pdf;
using iTextSharp.text.html;
using iTextSharp.text.html.simpleparser;
using iTextSharp.tool.xml;


public partial class Vistas_TablaPedidosNoRealizados : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!this.IsPostBack)
        {
            codes code = new codes();
            lbl_User.Text = code.UserLogin;
            code.llenar_tabla_NoPagadas(dataTable);
        }
    }

    public override void VerifyRenderingInServerForm(Control control)
    {

    }

    public void Buscador(object sender, EventArgs e){
        String GUIA = txt_busqueda.Text;
        codes code = new codes();
        code.Buscador_Guia(dataTable,GUIA);
    }
    public void Recargar(object sender, EventArgs e) {
        codes code = new codes();
        code.llenar_tabla_NoPagadas(dataTable);
    }
    protected void Export_xls(object sender, EventArgs e)
    {
        Response.Clear();
        Response.Buffer = true;
        Response.ClearContent();
        Response.ClearHeaders();
        Response.Charset = "";
        string FileName = "Reportes.xls";
        StringWriter strwritter = new StringWriter();
        HtmlTextWriter htmltextwrtter = new HtmlTextWriter(strwritter);
        Response.Cache.SetCacheability(HttpCacheability.NoCache);
        Response.ContentType = "application/vnd.ms-excel";
        Response.AddHeader("Content-Disposition", "attachment;filename=" + FileName);
        dataTable.GridLines = GridLines.Both;
        dataTable.HeaderStyle.Font.Bold = true;
        dataTable.RenderControl(htmltextwrtter);
        Response.Write(strwritter.ToString());
        Response.End();
    }
    protected void Export_pdf(object sender, EventArgs e)
    {
        using (StringWriter sw = new StringWriter())
        {
            using (HtmlTextWriter hw = new HtmlTextWriter(sw))
            {
                dataTable.RenderControl(hw);
                StringReader sr = new StringReader(sw.ToString());
                Document pdfDoc = new Document(PageSize.A2, 10f, 10f, 10f, 0f);
                PdfWriter writer = PdfWriter.GetInstance(pdfDoc, Response.OutputStream);
                pdfDoc.Open();
                XMLWorkerHelper.GetInstance().ParseXHtml(writer, pdfDoc, sr);
                pdfDoc.Close();
                Response.ContentType = "application/pdf";
                Response.AddHeader("content-disposition", "attachment;filename=Reportes.pdf");
                Response.Cache.SetCacheability(HttpCacheability.NoCache);
                Response.Write(pdfDoc);
                Response.End();
            }
        }
    }

    protected void dataTable_RowCommand(object sender, GridViewCommandEventArgs e)
    {
        try
        {
            if (e.CommandName == "Seleccionar_id")
            {
                String obtener_id = e.CommandArgument.ToString().Split()[0];
                int id = Convert.ToInt32(obtener_id);
                codes code = new codes();
                DatosGuias datos = new DatosGuias();
                datos.ID = id;
                if (code.Obtener_Datos(id))
                {
                    code.Redireccion = "TablaPedidosNoRealizados.aspx";
                    Response.Redirect("EditVentas.aspx");
                }
            }
        }
        catch
        {
            ClientScript.RegisterStartupScript(this.GetType(), "randomtext", "alertme()", true);
        }
    }
}