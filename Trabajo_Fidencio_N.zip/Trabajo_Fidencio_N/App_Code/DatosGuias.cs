﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

/// <summary>
/// Descripción breve de DatosGuias
/// </summary>
public class DatosGuias
{
    public DatosGuias()
    {
        //
        // TODO: Agregar aquí la lógica del constructor
        //
    }

    public static int id = 0;
    public int ID { get { return id; } set { id = value; } }
    public static String Guia = "";
    public String GUIA { get { return Guia; } set { Guia = value; } }
    public static String Nombre_Comprador = "";
    public String NOMBRE_COMPRADOR { get { return Nombre_Comprador; } set { Nombre_Comprador = value; } }
    public static String User_Vendedor = "";
    public String USER_VENDEDOR { get { return User_Vendedor; } set { User_Vendedor = value; } }
    public static String Direccion = "";
    public String DIRECCION { get { return Direccion; } set { Direccion = value; } }
    public static String Descripcion = "";
    public string DESCRIPCION { get { return Descripcion; } set { Descripcion = value; } }
    public static String Monto_Pagar = "";
    public String MONTO_PAGAR { get { return Monto_Pagar; } set { Monto_Pagar = value; } }
    public static String Fecha_Venta = "";
    public String FECHA_VENTA { get { return Fecha_Venta; } set { Fecha_Venta = value; } }
    public static bool Pagado = false;
    public bool PAGADO { get { return Pagado; } set { Pagado = value; } }
}