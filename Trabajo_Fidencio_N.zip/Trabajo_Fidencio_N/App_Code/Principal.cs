﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Configuration;

/// <summary>
/// Descripción breve de Principal
/// </summary>
public class Principal
{
    public Principal()
    {
        //
        // TODO: Agregar aquí la lógica del constructor
        //
    }
    public static string CnnStr0
    {
        get
        {
            return (ConfigurationManager.ConnectionStrings["dbCnnStr"].ConnectionString);
        }
    }
}