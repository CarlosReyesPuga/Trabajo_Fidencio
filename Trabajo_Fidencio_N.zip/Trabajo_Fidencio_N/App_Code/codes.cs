﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data;
using System.Data.SqlClient;
using System.Web.UI;
using System.Web.UI.WebControls;

/// <summary>
/// Descripción breve de codes
/// </summary>
public class codes
{
    public codes()
    {
        //
        // TODO: Agregar aquí la lógica del constructor
        //
    }

    public static bool admin = false;
    public bool ADMIN { get { return admin; } set { admin = value; } }
    public static String user_login = "";
    public String UserLogin { get { return user_login; } set { user_login = value; } }
    public static String redireccion = "";
    public String Redireccion { get { return redireccion; } set { redireccion = value; } }
    public static int Pedidos_Pagados = 0;
    public int PEDIDOS_PAGADOS { get { return Pedidos_Pagados; } set { Pedidos_Pagados = value; } }
    public static int Pedidos_NoPagados = 0;
    public int PEDIDOS_NOPAGADOS { get { return Pedidos_NoPagados; } set { Pedidos_NoPagados = value; } }

    public virtual bool Login(String User_Login, String password)
    {
        bool logg = false;
        SqlConnection cnn = new SqlConnection(Principal.CnnStr0);
        try
        {
            cnn.Open();
            SqlCommand cmd = new SqlCommand();
            cmd.Connection = cnn;
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.CommandText = "dbo.Logging_User";
            cmd.Parameters.Add("@User_Loging", SqlDbType.NVarChar, 100).Value = User_Login;
            cmd.Parameters.Add("@Password_User", SqlDbType.NVarChar, 50).Value = password;
            SqlDataReader dr = cmd.ExecuteReader();
            if (dr.Read())
            {
                admin = Convert.ToBoolean(dr["Admin_User"]);
                user_login = User_Login;
                logg = true;
            }
        }
        catch (Exception ex)
        {
            throw (ex);
        }
        finally
        {
            cnn.Close();
            cnn.Dispose();
        }
        return logg;
    }

    public virtual void Numero_Pedidos_Pagados()
    {
        SqlConnection cnn = new SqlConnection(Principal.CnnStr0);
        try
        {
            cnn.Open();
            SqlCommand cmd = new SqlCommand();
            cmd.Connection = cnn;
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.CommandText = "dbo.Numero_Pagados";
            SqlDataReader dr = cmd.ExecuteReader();
            if (dr.Read())
            {
                PEDIDOS_PAGADOS = Convert.ToInt32(dr["Pagado"]);
            }
        }
        catch (Exception ex)
        {
            throw (ex);
        }
        finally
        {
            cnn.Close();
            cnn.Dispose();
        }
    }
    public virtual void Numero_Pedidos_NoPagados()
    {
        SqlConnection cnn = new SqlConnection(Principal.CnnStr0);
        try
        {
            cnn.Open();
            SqlCommand cmd = new SqlCommand();
            cmd.Connection = cnn;
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.CommandText = "dbo.Numero_NoPagados";
            SqlDataReader dr = cmd.ExecuteReader();
            if (dr.Read())
            {
                PEDIDOS_NOPAGADOS = Convert.ToInt32(dr["NoPagado"]);
            }
        }
        catch (Exception ex)
        {
            throw (ex);
        }
        finally
        {
            cnn.Close();
            cnn.Dispose();
        }
    }
    public virtual bool Register_Usuario(String User_Name, String User_LastName, String User_Login, String password)
    {
        bool Regg = false;
        SqlConnection cnn = new SqlConnection(Principal.CnnStr0);
        try
        {
            cnn.Open();
            SqlCommand cmd = new SqlCommand();
            cmd.Connection = cnn;
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.CommandText = "Register_User";
            cmd.Parameters.Add("@Name_User", SqlDbType.NVarChar, 150).Value = User_Name;
            cmd.Parameters.Add("@Last_Name_User", SqlDbType.NVarChar, 200).Value = User_LastName;
            cmd.Parameters.Add("@User_Loging", SqlDbType.NVarChar, 100).Value = User_Login;
            cmd.Parameters.Add("@Password_User", SqlDbType.NVarChar, 50).Value = password;
            cmd.ExecuteNonQuery();
            Regg = true;

        }
        catch (Exception ex)
        {
            throw (ex);
        }
        finally
        {
            cnn.Close();
            cnn.Dispose();
        }
        return Regg;
    }

    public virtual bool Forgot_Password(String User_Login, String password)
    {
        bool forgg = false;
        SqlConnection cnn = new SqlConnection(Principal.CnnStr0);
        try
        {
            cnn.Open();
            SqlCommand cmd = new SqlCommand();
            cmd.Connection = cnn;
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.CommandText = "dbo.Forgot_Password";
            cmd.Parameters.Add("@User_Loging", SqlDbType.NVarChar, 100).Value = User_Login;
            cmd.Parameters.Add("@Password_User", SqlDbType.NVarChar, 50).Value = password;
            cmd.ExecuteNonQuery();
            forgg = true;

        }
        catch (Exception ex)
        {
            throw (ex);
        }
        finally
        {
            cnn.Close();
            cnn.Dispose();
        }
        return forgg;
    }

    public void llenar_tabla_NoPagadas(GridView grd)
    {
        SqlConnection cnn = new SqlConnection(Principal.CnnStr0);
        try
        {
            cnn.Open();
            SqlCommand cmd = new SqlCommand();
            cmd.Connection = cnn;
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.CommandText = "dbo.Ventas_NoPagadas";
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            da.Fill(dt);
            grd.DataSource = dt;
            grd.DataBind();
        }
        catch (Exception ex)
        {
            throw (ex);
        }
        finally
        {
            cnn.Dispose();
            cnn.Close();
        }
    }
    public void llenar_tabla_Pagadas(GridView grd)
    {
        SqlConnection cnn = new SqlConnection(Principal.CnnStr0);
        try
        {
            cnn.Open();
            SqlCommand cmd = new SqlCommand();
            cmd.Connection = cnn;
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.CommandText = "dbo.Ventas_Pagadas";
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            da.Fill(dt);
            grd.DataSource = dt;
            grd.DataBind();
        }
        catch (Exception ex)
        {
            throw (ex);
        }
        finally
        {
            cnn.Dispose();
            cnn.Close();
        }
    }

    public virtual bool Obtener_Datos(int id_Datos)
    {
        bool logg = false;
        SqlConnection cnn = new SqlConnection(Principal.CnnStr0);
        try
        {
            cnn.Open();
            SqlCommand cmd = new SqlCommand();
            cmd.Connection = cnn;
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.CommandText = "dbo.Buscador_Datos_Ventas";
            cmd.Parameters.Add("@id", SqlDbType.Int).Value = id_Datos;
            SqlDataReader dr = cmd.ExecuteReader();
            if (dr.Read())
            {
                DatosGuias datos = new DatosGuias();
                datos.GUIA = dr["Guia"].ToString();
                datos.NOMBRE_COMPRADOR = dr["Name_Comprador"].ToString();
                datos.DIRECCION = dr["Direccion"].ToString();
                datos.USER_VENDEDOR = dr["User_Vendedor"].ToString();
                datos.DESCRIPCION = dr["Descripcion_Venta"].ToString();
                datos.MONTO_PAGAR = dr["Monto_Pagar"].ToString();
                datos.FECHA_VENTA = dr["Fecha_Venta"].ToString();
                datos.PAGADO = Convert.ToBoolean(dr["Pagado"]);
                logg = true;
            }
        }
        catch (Exception ex)
        {
            throw (ex);
        }
        finally
        {
            cnn.Close();
            cnn.Dispose();
        }
        return logg;
    }
    public virtual bool Eliminar_Datos(int id_Datos)
    {
        bool logg = false;
        SqlConnection cnn = new SqlConnection(Principal.CnnStr0);
        try
        {
            cnn.Open();
            SqlCommand cmd = new SqlCommand();
            cmd.Connection = cnn;
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.CommandText = "dbo.Eliminar_Venta";
            cmd.Parameters.Add("@id", SqlDbType.Int).Value = id_Datos;
            cmd.ExecuteNonQuery();
            logg = true;
        }
        catch (Exception ex)
        {
            throw (ex);
        }
        finally
        {
            cnn.Close();
            cnn.Dispose();
        }
        return logg;
    }
    public virtual bool Registrar_Datos()
    {
        bool logg = false;
        SqlConnection cnn = new SqlConnection(Principal.CnnStr0);
        try
        {
            DatosGuias datos = new DatosGuias();
            cnn.Open();
            SqlCommand cmd = new SqlCommand();
            cmd.Connection = cnn;
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.CommandText = "dbo.Registrar_Ventas";
            cmd.Parameters.Add("@Guia", SqlDbType.NVarChar, 200).Value = datos.GUIA;
            cmd.Parameters.Add("@Name_Comprador", SqlDbType.NVarChar, 200).Value = datos.NOMBRE_COMPRADOR;
            cmd.Parameters.Add("@Direccion", SqlDbType.NVarChar, 500).Value = datos.DIRECCION;
            cmd.Parameters.Add("@User_Vendedor", SqlDbType.NVarChar, 100).Value = datos.USER_VENDEDOR;
            cmd.Parameters.Add("@Descripcion_Venta", SqlDbType.NVarChar, 500).Value = datos.DESCRIPCION;
            cmd.Parameters.Add("@Monto_Pagar", SqlDbType.NVarChar, 80).Value = datos.MONTO_PAGAR;
            cmd.Parameters.Add("@Fecha_Venta", SqlDbType.NVarChar, 50).Value = datos.FECHA_VENTA;
            cmd.Parameters.Add("@Pagado", SqlDbType.Bit).Value = datos.PAGADO;
            cmd.ExecuteNonQuery();
            logg = true;

        }
        catch (Exception ex)
        {
            throw (ex);
        }
        finally
        {
            cnn.Close();
            cnn.Dispose();
        }
        return logg;
    }
    public virtual bool Editar_Datos()
    {
        bool logg = false;
        SqlConnection cnn = new SqlConnection(Principal.CnnStr0);
        try
        {
            DatosGuias datos = new DatosGuias();
            cnn.Open();
            SqlCommand cmd = new SqlCommand();
            cmd.Connection = cnn;
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.CommandText = "dbo.Editar_Ventas";
            cmd.Parameters.Add("@id", SqlDbType.Int).Value = datos.ID;
            cmd.Parameters.Add("@Guia", SqlDbType.NVarChar, 200).Value = datos.GUIA;
            cmd.Parameters.Add("@Name_Comprador", SqlDbType.NVarChar, 200).Value = datos.NOMBRE_COMPRADOR;
            cmd.Parameters.Add("@Direccion", SqlDbType.NVarChar, 500).Value = datos.DIRECCION;
            cmd.Parameters.Add("@User_Vendedor", SqlDbType.NVarChar, 100).Value = datos.USER_VENDEDOR;
            cmd.Parameters.Add("@Descripcion_Venta", SqlDbType.NVarChar, 500).Value = datos.DESCRIPCION;
            cmd.Parameters.Add("@Monto_Pagar", SqlDbType.NVarChar, 80).Value = datos.MONTO_PAGAR;
            cmd.Parameters.Add("@Fecha_Venta", SqlDbType.NVarChar, 50).Value = datos.FECHA_VENTA;
            cmd.Parameters.Add("@Pagado", SqlDbType.Bit).Value = datos.PAGADO;
            cmd.ExecuteNonQuery();
            logg = true;

        }
        catch (Exception ex)
        {
            throw (ex);
        }
        finally
        {
            cnn.Close();
            cnn.Dispose();
        }
        return logg;
    }
    public virtual bool Buscador_Guia_1(GridView grd, String guia) {
        bool logg = false;
        SqlConnection cnn = new SqlConnection(Principal.CnnStr0);
        try
        {
            cnn.Open();
            SqlCommand cmd = new SqlCommand();
            cmd.Connection = cnn;
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.CommandText = "dbo.Buscar_NoPagados";
            cmd.Parameters.Add("@Guia", SqlDbType.NVarChar, 200).Value = guia;
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            da.Fill(dt);
            grd.DataSource = dt;
            grd.DataBind();
            logg = true;
        }
        catch (Exception ex)
        {
            throw (ex);
        }
        finally
        {
            cnn.Dispose();
            cnn.Close();
        }
        return logg;
    }
    public virtual bool Buscador_Guia_2(GridView grd, String guia)
    {
        bool logg = false;
        SqlConnection cnn = new SqlConnection(Principal.CnnStr0);
        try
        {
            cnn.Open();
            SqlCommand cmd = new SqlCommand();
            cmd.Connection = cnn;
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.CommandText = "dbo.Buscar_Pagados";
            cmd.Parameters.Add("@Guia", SqlDbType.NVarChar, 200).Value = guia;
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            da.Fill(dt);
            grd.DataSource = dt;
            grd.DataBind();
            logg = true;
        }
        catch (Exception ex)
        {
            throw (ex);
        }
        finally
        {
            cnn.Dispose();
            cnn.Close();
        }
        return logg;
    }
}